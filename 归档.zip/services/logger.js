/**
 * 灰·韵 HUI·YUN — 简易日志服务
 * 生产环境同时写入文件，开发环境仅控制台输出
 */

const fs = require('fs');
const path = require('path');
const config = require('../config');

const LOG_DIR = config.logDir;

// 确保日志目录存在
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

function timestamp() {
  return new Date().toISOString();
}

function format(level, tag, msg) {
  return `[${timestamp()}] [${level}] [${tag}] ${msg}`;
}

function writeFile(line) {
  try {
    const date = new Date().toISOString().slice(0, 10);
    fs.appendFileSync(path.join(LOG_DIR, `${date}.log`), line + '\n');
  } catch (_) { /* 静默失败 */ }
}

function info(tag, msg) {
  const line = format('INFO', tag, msg);
  console.log(line);
  if (config.isProduction) writeFile(line);
}

function warn(tag, msg) {
  const line = format('WARN', tag, msg);
  console.warn(line);
  if (config.isProduction) writeFile(line);
}

function error(tag, msg) {
  const line = format('ERROR', tag, msg);
  console.error(line);
  writeFile(line); // 错误始终写入
}

module.exports = { info, warn, error };