/**
 * 灰·韵 HUI·YUN — 邮件服务
 * 从 routes/auth.js 抽离，独立管理 SMTP 连接与邮件发送
 */

const nodemailer = require('nodemailer');
const config = require('../config');

let transporter = null;
let mode = 'console'; // 'smtp' | 'console'

function init() {
  const { host, port, secure, user, pass } = config.smtp;

  if (host && user && pass) {
    transporter = nodemailer.createTransport({
      host, port, secure,
      auth: { user, pass }
    });
    mode = 'smtp';
    console.log(`[邮件] SMTP 已配置 (${host})`);
  } else {
    console.log('[邮件] SMTP 未配置，验证码将输出到控制台');
    console.log('[邮件] 请在 .env 中配置 SMTP_HOST, SMTP_USER, SMTP_PASS');
  }
}

function getMode() {
  return mode;
}

function generateCode() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

async function sendVerification(email, code, type) {
  const subject = type === 'register'
    ? '【灰·韵】邮箱验证码 - 注册账号'
    : '【灰·韵】邮箱验证码 - 登录';

  const html = `<div style="max-width:600px;margin:0 auto;padding:30px;font-family:'PingFang SC','Microsoft YaHei',sans-serif;background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);border-radius:16px;color:#e0e0e0;"><div style="text-align:center;margin-bottom:24px;"><h1 style="color:#ff6b9d;font-size:28px;margin:0;">灰·韵 HUI·YUN</h1><p style="color:#999;font-size:14px;">你的个人聚合页平台</p></div><div style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:24px;text-align:center;"><p style="font-size:16px;margin-bottom:16px;">${type === 'register' ? '感谢注册灰·韵，你的验证码是：' : '你的登录验证码是：'}</p><div style="font-size:36px;font-weight:bold;letter-spacing:8px;color:#ff6b9d;background:rgba(255,107,157,0.1);padding:12px 24px;border-radius:8px;display:inline-block;margin:12px 0;">${code}</div><p style="color:#888;font-size:13px;margin-top:16px;">验证码10分钟内有效，请勿泄露给他人</p></div><div style="text-align:center;margin-top:24px;color:#666;font-size:12px;"><p>灰·韵 HUI·YUN © 2026</p></div></div>`;

  if (mode === 'smtp' && transporter) {
    try {
      await transporter.sendMail({ from: config.smtp.from, to: email, subject, html });
      console.log(`[邮件] 验证码已发送至 ${email}`);
      return true;
    } catch (err) {
      console.error('[邮件] 发送失败:', err.message);
      console.log(`[邮件] 降级模式 - 验证码 ${code} 已输出到控制台（发送至 ${email}）`);
      return false;
    }
  } else {
    console.log(`\n========================================`);
    console.log(`[邮件模拟] 收件人: ${email}`);
    console.log(`[邮件模拟] 验证码: ${code}`);
    console.log(`[邮件模拟] 类型: ${type}`);
    console.log(`========================================\n`);
    return true;
  }
}

module.exports = { init, getMode, generateCode, sendVerification };