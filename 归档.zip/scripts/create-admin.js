/**
 * 灰·韵 HUI·YUN — 手动创建管理员账号
 *
 * 用法：
 *   node scripts/create-admin.js
 *   node scripts/create-admin.js --reset  (重置密码)
 *
 * 当 seed.js 静默失败、或不方便重启服务器时，用此脚本手动创建管理员。
 */

require('dotenv').config();
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
const config = require('../config');

const ADMIN = config.admin;

async function main() {
  const args = process.argv.slice(2);
  const shouldReset = args.includes('--reset');

  console.log('[创建管理员] 正在连接数据库...');

  let conn;
  try {
    conn = await mysql.createConnection({
      host: config.db.host,
      port: config.db.port,
      user: config.db.user,
      password: config.db.password,
      database: config.db.database,
      charset: config.db.charset
    });
    console.log(`[创建管理员] 数据库已连接 (${config.db.host}:${config.db.port}/${config.db.database})`);
  } catch (err) {
    console.error(`\n❌ 数据库连接失败: ${err.message}`);
    console.error('\n请检查 .env 中的数据库配置：');
    console.error(`  DB_HOST=${config.db.host}`);
    console.error(`  DB_PORT=${config.db.port}`);
    console.error(`  DB_USER=${config.db.user}`);
    console.error(`  DB_NAME=${config.db.database}`);
    console.error('\n排查步骤：');
    console.error('  1. 确认 MySQL 服务正在运行');
    console.error('  2. 确认数据库用户和密码正确');
    console.error('  3. 确认数据库已创建：CREATE DATABASE huiyun CHARACTER SET utf8mb4;');
    process.exit(1);
  }

  // 检查用户表是否存在
  try {
    await conn.execute('SELECT 1 FROM users LIMIT 1');
  } catch (err) {
    console.error('\n❌ users 表不存在，请先启动一次服务器让数据库自动建表');
    console.error('   运行: node server.js');
    await conn.end();
    process.exit(1);
  }

  // 查询现有管理员
  const [rows] = await conn.execute('SELECT id, username, email, role FROM users WHERE username = ?', [ADMIN.username]);

  if (rows.length > 0 && !shouldReset) {
    const user = rows[0];
    console.log(`\n✅ 管理员账号已存在:`);
    console.log(`   用户名: ${user.username}`);
    console.log(`   邮箱:   ${user.email}`);
    console.log(`   角色:   ${user.role}`);
    if (user.role !== 'admin') {
      await conn.execute('UPDATE users SET role = ? WHERE id = ?', ['admin', user.id]);
      console.log(`   ⚠️  角色已修正为 admin`);
    }
    console.log(`\n如需重置密码，运行: node scripts/create-admin.js --reset`);
    await conn.end();
    return;
  }

  if (rows.length > 0 && shouldReset) {
    const passwordHash = bcrypt.hashSync(ADMIN.password, 10);
    await conn.execute('UPDATE users SET password_hash = ?, role = ? WHERE username = ?', [passwordHash, 'admin', ADMIN.username]);
    console.log(`\n🔑 管理员密码已重置:`);
    console.log(`   用户名: ${ADMIN.username}`);
    console.log(`   密码:   ${ADMIN.password}`);
    await conn.end();
    return;
  }

  // 创建管理员
  const passwordHash = bcrypt.hashSync(ADMIN.password, 10);
  await conn.execute(
    'INSERT INTO users (username, nickname, email, password_hash, role, is_public) VALUES (?, ?, ?, ?, ?, ?)',
    [ADMIN.username, ADMIN.nickname, ADMIN.email, passwordHash, 'admin', 0]
  );

  console.log(`\n========================================`);
  console.log(`  ✅ 管理员账号创建成功！`);
  console.log(`  用户名: ${ADMIN.username}`);
  console.log(`  邮箱:   ${ADMIN.email}`);
  console.log(`  密码:   ${ADMIN.password}`);
  console.log(`  🔴 请立即登录并修改密码！`);
  console.log(`========================================`);

  await conn.end();
}

main().catch(err => {
  console.error('\n❌ 未知错误:', err.message);
  process.exit(1);
});