<?php
/**
 * 灰·韵 HUI·YUN — 配置文件
 * 替代原来的 .env + config/index.js
 * 
 * 部署时修改下面的数据库和站点信息即可
 */

// ========== 站点 ==========
define('SITE_URL', 'https://153900.xyz');
define('SITE_NAME', '灰·韵 HUI·YUN');

// ========== 数据库 ==========
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'huiyun');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// ========== JWT 密钥（务必修改为随机字符串）==========
define('JWT_SECRET', 'huiyun_secret_key_change_in_production');
define('JWT_EXPIRES', 30 * 24 * 3600); // 30天

// ========== SMTP 邮件（可选，不填则验证码显示在页面上）==========
define('SMTP_HOST', '');
define('SMTP_PORT', '465');
define('SMTP_SECURE', 'true');
define('SMTP_USER', '');
define('SMTP_PASS', '');
define('SMTP_FROM', '');

// ========== 上传 ==========
define('UPLOAD_DIR', __DIR__ . '/uploads');
define('AVATAR_MAX_SIZE', 5 * 1024 * 1024);  // 5MB
define('BG_MAX_SIZE', 10 * 1024 * 1024);     // 10MB

// ========== 管理员 ==========
define('ADMIN_USERNAME', 'admin');
define('ADMIN_NICKNAME', '灰·韵管理员');
define('ADMIN_EMAIL', 'admin@153900.xyz');
define('ADMIN_PASSWORD', 'admin123456');

// ========== 速率限制 ==========
define('RATE_LIMIT_API', 200);      // 每15分钟
define('RATE_LIMIT_AUTH', 20);      // 每15分钟