/**
 * 灰·韵 HUI·YUN — PM2 进程管理配置
 * 使用: pm2 start ecosystem.config.js
 * 文档: https://pm2.keymetrics.io/
 */

module.exports = {
  apps: [{
    name: 'huiyun',
    script: 'server.js',
    cwd: __dirname,

    // 进程数（512MB 内存建议单实例）
    instances: 1,
    exec_mode: 'fork',

    // 环境变量
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },

    // 自动重启
    max_memory_restart: '300M',
    max_restarts: 10,
    restart_delay: 5000,

    // 日志
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    error_file: './logs/pm2-error.log',
    out_file: './logs/pm2-out.log',
    merge_logs: true,

    // 优雅退出
    kill_timeout: 10000,
    wait_ready: false,
    listen_timeout: 5000,

    // 监控
    instance_var: 'INSTANCE_ID'
  }]
};