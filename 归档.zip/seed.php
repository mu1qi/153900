<?php
/**
 * 灰·韵 HUI·YUN — 管理员账号创建脚本
 * 
 * 访问方式：浏览器打开 https://153900.xyz/seed.php
 * 首次运行创建管理员，之后每次访问检查账号状态
 * 
 * 部署后建议删除此文件或重命名为 seed.php.bak
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';

?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>管理员账号管理 - 灰·韵 HUI·YUN</title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
        font-family: -apple-system,"PingFang SC","Microsoft YaHei",sans-serif;
        background: #0d1117; color: #e6edf3; min-height: 100vh;
        display: flex; align-items: center; justify-content: center;
    }
    .card {
        background: #161b22; border: 1px solid #30363d; border-radius: 12px;
        padding: 40px; max-width: 520px; width: 90%;
    }
    h1 { font-size: 1.4rem; color: #ff6b9d; margin-bottom: 20px; }
    .info { background: rgba(88,166,255,0.08); border-left: 3px solid #58a6ff; padding: 12px 16px; border-radius: 4px; margin: 12px 0; font-size: 0.9rem; }
    .success { border-color: #3fb950; background: rgba(63,185,80,0.08); }
    .error { border-color: #f85149; background: rgba(248,81,73,0.08); }
    table { width: 100%; border-collapse: collapse; margin: 16px 0; }
    td { padding: 8px 12px; border-bottom: 1px solid #30363d; }
    td:first-child { color: #8b949e; width: 80px; }
    td:last-child { font-weight: 600; }
    .btn { display: inline-block; padding: 8px 20px; background: #ff6b9d; color: #fff; border: none; border-radius: 6px; text-decoration: none; font-size: 0.9rem; cursor: pointer; margin-top: 8px; }
    .btn:hover { background: #e85d8a; }
    .btn-ghost { background: transparent; border: 1px solid #30363d; color: #8b949e; }
    .btn-ghost:hover { background: #30363d; color: #e6edf3; }
    .danger { background: #f85149; }
    .danger:hover { background: #da3633; }
</style>
</head>
<body>
<div class="card">
<h1>🔧 管理员账号管理</h1>
<?php

try {
    initDatabase();

    $action = $_GET['action'] ?? '';
    $existing = queryOne('SELECT id, username, email, role FROM users WHERE username = ?', [ADMIN_USERNAME]);

    if ($action === 'reset' && $existing) {
        $hash = password_hash(ADMIN_PASSWORD, PASSWORD_BCRYPT);
        dbRun('UPDATE users SET password_hash = ?, role = ? WHERE id = ?', [$hash, 'admin', $existing['id']]);
        echo '<div class="info success">✅ 密码已重置为默认值</div>';
    } elseif ($action === 'delete' && $existing) {
        dbRun('DELETE FROM users WHERE id = ?', [$existing['id']]);
        echo '<div class="info success">✅ 管理员账号已删除，刷新页面将重新创建</div>';
        $existing = null;
    }

    if (!$existing) {
        $hash = password_hash(ADMIN_PASSWORD, PASSWORD_BCRYPT);
        dbRun(
            'INSERT INTO users (username, nickname, email, password_hash, role, is_public) VALUES (?, ?, ?, ?, ?, ?)',
            [ADMIN_USERNAME, ADMIN_NICKNAME, ADMIN_EMAIL, $hash, 'admin', 0]
        );
        echo '<div class="info success">✅ 管理员账号已创建！</div>';
        $existing = queryOne('SELECT id, username, email, role FROM users WHERE username = ?', [ADMIN_USERNAME]);
    }

    echo '<table>';
    echo '<tr><td>用户名</td><td>' . h($existing['username']) . '</td></tr>';
    echo '<tr><td>邮箱</td><td>' . h($existing['email']) . '</td></tr>';
    echo '<tr><td>密码</td><td>' . ADMIN_PASSWORD . '</td></tr>';
    echo '<tr><td>角色</td><td>' . h($existing['role']) . '</td></tr>';
    echo '</table>';

    echo '<div class="info">🔴 <strong>请立即登录并修改密码！</strong>默认密码是公开的。</div>';
    echo '<a href="/admin" class="btn">进入管理后台</a> ';
    echo '<a href="?action=reset" class="btn btn-ghost" onclick="return confirm(\'确认重置密码？\')">重置密码</a> ';
    echo '<a href="?action=delete" class="btn btn-ghost danger" onclick="return confirm(\'确认删除管理员账号？\')">删除账号</a>';

} catch (Exception $e) {
    echo '<div class="info error">❌ 错误：' . h($e->getMessage()) . '</div>';
    echo '<p style="color:#8b949e;font-size:0.85rem;margin-top:8px;">请检查 config.php 中的数据库配置是否正确。</p>';
}
?>
</div>
</body>
</html>