<?php
/**
 * 灰·韵 HUI·YUN — API 路由
 * 替代原来的 routes/*.js 所有 Express 路由
 * 
 * URL 映射（通过 .htaccess 重写）：
 *   /api/auth/login    → api.php?path=auth/login
 *   /api/user/profile  → api.php?path=user/profile
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';

// 初始化数据库表
initDatabase();

// 解析请求路径
$path = $_GET['path'] ?? '';
$path = trim($path, '/');
$method = getMethod();

// 设置 CORS 和 JSON 响应头
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ==================== 路由分发 ====================

// -- 认证 --
if (preg_match('#^auth/send-code$#', $path) && $method === 'POST')           { handleSendCode(); }
elseif (preg_match('#^auth/register$#', $path) && $method === 'POST')        { handleRegister(); }
elseif (preg_match('#^auth/login$#', $path) && $method === 'POST')           { handleLogin(); }
elseif (preg_match('#^auth/login/send-code$#', $path) && $method === 'POST') { handleLoginSendCode(); }
elseif (preg_match('#^auth/login/verify$#', $path) && $method === 'POST')    { handleLoginVerify(); }
elseif (preg_match('#^auth/me$#', $path) && $method === 'GET')               { handleMe(); }

// -- 用户 --
elseif (preg_match('#^user/profile$#', $path) && $method === 'PUT')          { handleUpdateProfile(); }
elseif (preg_match('#^user/profile/(.+)$#', $path, $m) && $method === 'GET') { handleGetProfile($m[1]); }
elseif (preg_match('#^user/social-links$#', $path) && $method === 'PUT')     { handleUpdateSocialLinks(); }
elseif (preg_match('#^user/music$#', $path) && $method === 'PUT')            { handleUpdateMusic(); }
elseif (preg_match('#^user/theme$#', $path) && $method === 'PUT')            { handleUpdateTheme(); }
elseif (preg_match('#^user/visit/(.+)$#', $path, $m) && $method === 'POST')  { handleRecordVisit($m[1]); }

// -- 发现 --
elseif (preg_match('#^discover$#', $path) && $method === 'GET')              { handleDiscover(); }
elseif (preg_match('#^discover/like/(.+)$#', $path, $m) && $method === 'POST') { handleLike($m[1]); }
elseif (preg_match('#^discover/like/(.+)/check$#', $path, $m) && $method === 'GET') { handleCheckLike($m[1]); }

// -- 上传 --
elseif (preg_match('#^upload/avatar$#', $path) && $method === 'POST')        { handleUploadAvatar(); }
elseif (preg_match('#^upload/background$#', $path) && $method === 'POST')    { handleUploadBackground(); }
elseif (preg_match('#^upload/qrcode/(.+)$#', $path, $m) && $method === 'GET') { handleQRCode($m[1]); }

// -- 管理员 --
elseif (preg_match('#^admin/stats$#', $path) && $method === 'GET')           { handleAdminStats(); }
elseif (preg_match('#^admin/users$#', $path) && $method === 'GET')           { handleAdminUsers(); }
elseif (preg_match('#^admin/users/(\d+)$#', $path, $m) && $method === 'GET') { handleAdminUserDetail($m[1]); }
elseif (preg_match('#^admin/users/(\d+)/toggle-public$#', $path, $m) && $method === 'PUT') { handleAdminTogglePublic($m[1]); }
elseif (preg_match('#^admin/users/(\d+)/role$#', $path, $m) && $method === 'PUT') { handleAdminSetRole($m[1]); }
elseif (preg_match('#^admin/users/(\d+)$#', $path, $m) && $method === 'DELETE') { handleAdminDeleteUser($m[1]); }
elseif (preg_match('#^admin/users/(\d+)/reset-password$#', $path, $m) && $method === 'POST') { handleAdminResetPassword($m[1]); }

// 404
else {
    jsonError(404, '接口不存在');
}

// ==================== 认证处理 ====================

function handleSendCode() {
    $data = getJsonInput();
    $email = $data['email'] ?? '';
    $type = $data['type'] ?? 'register';

    if (!$email) jsonError(400, '请输入邮箱');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonError(400, '邮箱格式不正确');
    if (!checkRateLimit($email)) jsonError(429, '请60秒后再试');

    $code = generateCode();
    dbRun(
        "INSERT INTO email_verifications (email, code, type, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE))",
        [$email, $code, $type]
    );
    sendVerificationEmail($email, $code, $type);
    jsonResponse(['message' => '验证码已发送']);
}

function handleRegister() {
    $data = getJsonInput();
    $username = trim($data['username'] ?? '');
    $nickname = trim($data['nickname'] ?? '');
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';
    $code = $data['code'] ?? '';

    if (!$username || !$nickname || !$email || !$password || !$code) jsonError(400, '请填写所有字段');
    if (!preg_match('/^[a-zA-Z0-9_\x{4e00}-\x{9fa5}]{2,20}$/u', $username)) jsonError(400, '用户名需2-20位字母、数字或中文');
    if (strlen($password) < 6) jsonError(400, '密码至少6位');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonError(400, '邮箱格式不正确');

    if (!verifyEmailCode($email, $code, 'register')) jsonError(400, '验证码错误或已过期');
    if (queryOne('SELECT id FROM users WHERE username = ?', [$username])) jsonError(400, '用户名已被注册');
    if (queryOne('SELECT id FROM users WHERE email = ?', [$email])) jsonError(400, '邮箱已被注册');

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $result = dbRun(
        'INSERT INTO users (username, nickname, email, password_hash) VALUES (?, ?, ?, ?)',
        [$username, $nickname, $email, $hash]
    );

    $userId = $result['lastInsertId'];
    $token = generateToken($userId, $username, 'user');
    jsonResponse([
        'message' => '注册成功',
        'token' => $token,
        'user' => ['id' => $userId, 'username' => $username, 'nickname' => $nickname, 'email' => $email, 'avatar_url' => '', 'bio' => '', 'theme_name' => 'sakura', 'accent_color' => '#ff6b9d', 'role' => 'user']
    ]);
}

function handleLoginSendCode() {
    $data = getJsonInput();
    $email = $data['email'] ?? '';
    if (!$email) jsonError(400, '请输入邮箱');
    if (!queryOne('SELECT id FROM users WHERE email = ?', [$email])) jsonError(400, '该邮箱未注册');

    $code = generateCode();
    dbRun("INSERT INTO email_verifications (email, code, type, expires_at) VALUES (?, ?, 'login', DATE_ADD(NOW(), INTERVAL 10 MINUTE))", [$email, $code]);
    sendVerificationEmail($email, $code, 'login');
    jsonResponse(['message' => '验证码已发送']);
}

function handleLoginVerify() {
    $data = getJsonInput();
    $email = $data['email'] ?? '';
    $code = $data['code'] ?? '';
    if (!$email || !$code) jsonError(400, '请输入邮箱和验证码');
    if (!verifyEmailCode($email, $code, 'login')) jsonError(400, '验证码错误或已过期');

    $user = queryOne('SELECT * FROM users WHERE email = ?', [$email]);
    $token = generateToken($user['id'], $user['username'], $user['role']);
    jsonResponse(['message' => '登录成功', 'token' => $token, 'user' => formatUser($user)]);
}

function handleLogin() {
    $data = getJsonInput();
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';
    if (!$email || !$password) jsonError(400, '请输入邮箱和密码');

    $user = queryOne('SELECT * FROM users WHERE email = ?', [$email]);
    if (!$user || !password_verify($password, $user['password_hash'])) jsonError(400, '邮箱或密码错误');

    $token = generateToken($user['id'], $user['username'], $user['role']);
    jsonResponse(['message' => '登录成功', 'token' => $token, 'user' => formatUser($user)]);
}

function handleMe() {
    $payload = requireAuth();
    $user = queryOne(
        'SELECT id, username, nickname, email, role, avatar_url, bio, theme_name, accent_color, custom_bg_url, is_public, created_at FROM users WHERE id = ?',
        [$payload['userId']]
    );
    if (!$user) jsonError(404, '用户不存在');

    $socialLinks = queryAll('SELECT * FROM social_links WHERE user_id = ? ORDER BY sort_order ASC', [$user['id']]);
    $music = queryOne('SELECT * FROM music_settings WHERE user_id = ?', [$user['id']]);
    $likeCount = queryOne('SELECT COUNT(*) as count FROM likes WHERE user_id = ?', [$user['id']])['count'] ?? 0;
    $visitCount = queryOne('SELECT COUNT(*) as count FROM visit_stats WHERE user_id = ?', [$user['id']])['count'] ?? 0;

    jsonResponse([
        'user' => $user,
        'socialLinks' => $socialLinks,
        'music' => $music ?: ['type' => 'netease', 'music_url' => '', 'music_id' => '', 'title' => '', 'artist' => '', 'autoplay' => 0],
        'likeCount' => (int)$likeCount,
        'visitCount' => (int)$visitCount
    ]);
}

// ==================== 用户处理 ====================

function handleGetProfile($username) {
    $user = queryOne('SELECT id, username, nickname, avatar_url, bio, theme_name, accent_color, custom_bg_url, is_public, created_at FROM users WHERE username = ?', [$username]);
    if (!$user) jsonError(404, '用户不存在');
    if (!$user['is_public']) jsonError(403, '该用户已隐藏主页');

    $socialLinks = queryAll('SELECT * FROM social_links WHERE user_id = ? ORDER BY sort_order ASC', [$user['id']]);
    $music = queryOne('SELECT * FROM music_settings WHERE user_id = ?', [$user['id']]);
    $likeCount = queryOne('SELECT COUNT(*) as count FROM likes WHERE user_id = ?', [$user['id']])['count'] ?? 0;
    $visitCount = queryOne('SELECT COUNT(*) as count FROM visit_stats WHERE user_id = ?', [$user['id']])['count'] ?? 0;

    jsonResponse([
        'user' => $user,
        'socialLinks' => $socialLinks,
        'music' => $music ?: ['type' => 'netease', 'music_url' => '', 'music_id' => '', 'title' => '', 'artist' => '', 'autoplay' => 0],
        'likeCount' => (int)$likeCount,
        'visitCount' => (int)$visitCount
    ]);
}

function handleUpdateProfile() {
    $payload = requireAuth();
    $data = getJsonInput();
    $fields = [];
    $params = [];

    foreach (['nickname', 'avatar_url', 'bio', 'is_public', 'theme_name', 'accent_color', 'custom_bg_url'] as $f) {
        if (isset($data[$f])) {
            $fields[] = "$f = ?";
            $params[] = $data[$f];
        }
    }

    if (empty($fields)) jsonError(400, '没有要更新的字段');
    $params[] = $payload['userId'];
    dbRun('UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?', $params);
    jsonResponse(['message' => '更新成功']);
}

function handleUpdateSocialLinks() {
    $payload = requireAuth();
    $data = getJsonInput();
    $links = $data['links'] ?? [];

    dbRun('DELETE FROM social_links WHERE user_id = ?', [$payload['userId']]);
    foreach ($links as $i => $link) {
        if (!empty($link['platform']) && !empty($link['url'])) {
            dbRun('INSERT INTO social_links (user_id, platform, platform_label, url, sort_order, link_type) VALUES (?, ?, ?, ?, ?, ?)',
                [$payload['userId'], $link['platform'], $link['platform_label'] ?? $link['platform'], $link['url'], $i, $link['link_type'] ?? 'link']);
        }
    }
    jsonResponse(['message' => '更新成功']);
}

function handleUpdateMusic() {
    $payload = requireAuth();
    $data = getJsonInput();
    $existing = queryOne('SELECT id FROM music_settings WHERE user_id = ?', [$payload['userId']]);

    if ($existing) {
        dbRun(
            'UPDATE music_settings SET type=?, music_url=?, music_id=?, title=?, artist=?, autoplay=? WHERE user_id=?',
            [$data['type'] ?? 'netease', $data['music_url'] ?? '', $data['music_id'] ?? '', $data['title'] ?? '', $data['artist'] ?? '', $data['autoplay'] ?? 0, $payload['userId']]
        );
    } else {
        dbRun(
            'INSERT INTO music_settings (user_id, type, music_url, music_id, title, artist, autoplay) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$payload['userId'], $data['type'] ?? 'netease', $data['music_url'] ?? '', $data['music_id'] ?? '', $data['title'] ?? '', $data['artist'] ?? '', $data['autoplay'] ?? 0]
        );
    }
    jsonResponse(['message' => '更新成功']);
}

function handleUpdateTheme() {
    $payload = requireAuth();
    $data = getJsonInput();
    $fields = [];
    $params = [];
    foreach (['theme_name', 'accent_color', 'custom_bg_url'] as $f) {
        if (isset($data[$f])) {
            $fields[] = "$f = ?";
            $params[] = $data[$f];
        }
    }
    if (empty($fields)) jsonError(400, '没有要更新的字段');
    $params[] = $payload['userId'];
    dbRun('UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?', $params);
    jsonResponse(['message' => '更新成功']);
}

function handleRecordVisit($username) {
    $user = queryOne('SELECT id FROM users WHERE username = ?', [$username]);
    if (!$user) jsonError(404, '用户不存在');
    $ip = getClientIP();
    // 5分钟内重复访问不计数
    $recent = queryOne(
        'SELECT id FROM visit_stats WHERE user_id = ? AND visitor_ip = ? AND visited_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)',
        [$user['id'], $ip]
    );
    if (!$recent) {
        dbRun('INSERT INTO visit_stats (user_id, visitor_ip) VALUES (?, ?)', [$user['id'], $ip]);
    }
    jsonResponse(['message' => 'ok']);
}

// ==================== 发现处理 ====================

function handleDiscover() {
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = 20;
    $offset = ($page - 1) * $limit;

    $sort = $_GET['sort'] ?? 'newest';
    $order = 'created_at DESC';

    if ($sort === 'likes') {
        $order = '(SELECT COUNT(*) FROM likes WHERE likes.user_id = users.id) DESC';
    } elseif ($sort === 'visits') {
        $order = '(SELECT COUNT(*) FROM visit_stats WHERE visit_stats.user_id = users.id) DESC';
    }

    $total = queryOne('SELECT COUNT(*) as count FROM users WHERE is_public = 1')['count'];
    $users = queryAll(
        "SELECT id, username, nickname, avatar_url, bio, theme_name, accent_color, custom_bg_url, created_at FROM users WHERE is_public = 1 ORDER BY $order LIMIT ? OFFSET ?",
        [$limit, $offset]
    );

    $result = [];
    foreach ($users as $u) {
        $likeCount = queryOne('SELECT COUNT(*) as count FROM likes WHERE user_id = ?', [$u['id']])['count'] ?? 0;
        $visitCount = queryOne('SELECT COUNT(*) as count FROM visit_stats WHERE user_id = ?', [$u['id']])['count'] ?? 0;
        $u['like_count'] = (int)$likeCount;
        $u['visit_count'] = (int)$visitCount;
        $u['likeCount'] = (int)$likeCount;
        $u['visitCount'] = (int)$visitCount;
        $result[] = $u;
    }

    jsonResponse([
        'users' => $result,
        'total' => (int)$total,
        'page' => $page,
        'pageSize' => $limit,
        'pagination' => [
            'currentPage' => $page,
            'totalPages' => (int)ceil($total / $limit),
            'total' => (int)$total
        ]
    ]);
}

function handleLike($username) {
    $user = queryOne('SELECT id FROM users WHERE username = ?', [$username]);
    if (!$user) jsonError(404, '用户不存在');
    $ip = getClientIP();
    try {
        dbRun('INSERT INTO likes (user_id, liked_by_ip) VALUES (?, ?)', [$user['id'], $ip]);
        $count = queryOne('SELECT COUNT(*) as count FROM likes WHERE user_id = ?', [$user['id']])['count'];
        jsonResponse(['liked' => true, 'likeCount' => (int)$count]);
    } catch (Exception $e) {
        // 已点赞
        dbRun('DELETE FROM likes WHERE user_id = ? AND liked_by_ip = ?', [$user['id'], $ip]);
        $count = queryOne('SELECT COUNT(*) as count FROM likes WHERE user_id = ?', [$user['id']])['count'];
        jsonResponse(['liked' => false, 'likeCount' => (int)$count]);
    }
}

function handleCheckLike($username) {
    $user = queryOne('SELECT id FROM users WHERE username = ?', [$username]);
    if (!$user) jsonError(404, '用户不存在');
    $ip = getClientIP();
    $row = queryOne('SELECT id FROM likes WHERE user_id = ? AND liked_by_ip = ?', [$user['id'], $ip]);
    jsonResponse(['liked' => $row ? true : false]);
}

// ==================== 上传处理 ====================

function handleUploadAvatar() {
    $payload = requireAuth();
    handleFileUpload('avatar', $payload['userId'], AVATAR_MAX_SIZE, 'avatars');
}

function handleUploadBackground() {
    $payload = requireAuth();
    handleFileUpload('background', $payload['userId'], BG_MAX_SIZE, 'backgrounds');
}

function handleFileUpload($type, $userId, $maxSize, $subDir) {
    if (!isset($_FILES['file'])) jsonError(400, '请选择文件');
    $file = $_FILES['file'];
    if ($file['error'] !== UPLOAD_ERR_OK) jsonError(400, '上传失败');

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) jsonError(400, '不支持的图片格式');
    if ($file['size'] > $maxSize) jsonError(400, '文件过大');

    $dir = UPLOAD_DIR . '/' . $subDir;
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $filename = $userId . '_' . time() . '.' . $ext;
    $dest = $dir . '/' . $filename;
    move_uploaded_file($file['tmp_name'], $dest);

    $url = '/uploads/' . $subDir . '/' . $filename;
    $field = $type === 'avatar' ? 'avatar_url' : 'custom_bg_url';
    dbRun("UPDATE users SET $field = ? WHERE id = ?", [$url, $userId]);

    jsonResponse(['url' => $url, 'message' => '上传成功']);
}

function handleQRCode($username) {
    $url = SITE_URL . '/' . urlencode($username);
    $qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($url);
    header('Content-Type: image/png');
    readfile($qrUrl);
    exit;
}

// ==================== 管理员处理 ====================

function handleAdminStats() {
    requireAdmin();
    $totalUsers = queryOne('SELECT COUNT(*) as c FROM users')['c'];
    $publicUsers = queryOne('SELECT COUNT(*) as c FROM users WHERE is_public = 1')['c'];
    $totalLikes = queryOne('SELECT COUNT(*) as c FROM likes')['c'];
    $totalVisits = queryOne('SELECT COUNT(*) as c FROM visit_stats')['c'];
    $adminCount = queryOne("SELECT COUNT(*) as c FROM users WHERE role = 'admin'")['c'];
    $todayUsers = queryOne('SELECT COUNT(*) as c FROM users WHERE DATE(created_at) = CURDATE()')['c'];

    jsonResponse([
        'totalUsers' => (int)$totalUsers,
        'publicUsers' => (int)$publicUsers,
        'totalLikes' => (int)$totalLikes,
        'totalVisits' => (int)$totalVisits,
        'adminCount' => (int)$adminCount,
        'todayUsers' => (int)$todayUsers
    ]);
}

function handleAdminUsers() {
    requireAdmin();
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = 20;
    $offset = ($page - 1) * $limit;
    $search = $_GET['search'] ?? '';
    $sort = $_GET['sort'] ?? 'created_at';
    $order = strtoupper($_GET['order'] ?? 'DESC');

    $allowedSorts = ['created_at', 'username', 'role', 'id'];
    if (!in_array($sort, $allowedSorts)) $sort = 'created_at';
    if (!in_array($order, ['ASC', 'DESC'])) $order = 'DESC';

    $where = '';
    $params = [];
    if ($search) {
        $where = "WHERE (username LIKE ? OR nickname LIKE ? OR email LIKE ?)";
        $s = "%$search%";
        $params = [$s, $s, $s];
    }

    $total = queryOne("SELECT COUNT(*) as c FROM users $where", $params)['c'];
    $params[] = $limit;
    $params[] = $offset;
    $users = queryAll("SELECT id, username, nickname, email, role, is_public, created_at FROM users $where ORDER BY $sort $order LIMIT ? OFFSET ?", $params);

    jsonResponse(['users' => $users, 'total' => (int)$total, 'page' => $page]);
}

function handleAdminUserDetail($id) {
    requireAdmin();
    $user = queryOne('SELECT * FROM users WHERE id = ?', [(int)$id]);
    if (!$user) jsonError(404, '用户不存在');
    unset($user['password_hash']);
    jsonResponse(['user' => $user]);
}

function handleAdminTogglePublic($id) {
    requireAdmin();
    $user = queryOne('SELECT id, is_public FROM users WHERE id = ?', [(int)$id]);
    if (!$user) jsonError(404, '用户不存在');
    $newVal = $user['is_public'] ? 0 : 1;
    dbRun('UPDATE users SET is_public = ? WHERE id = ?', [$newVal, (int)$id]);
    jsonResponse(['message' => '更新成功', 'is_public' => $newVal]);
}

function handleAdminSetRole($id) {
    requireAdmin();
    $data = getJsonInput();
    $role = $data['role'] ?? 'user';
    if (!in_array($role, ['admin', 'user'])) jsonError(400, '无效角色');
    dbRun('UPDATE users SET role = ? WHERE id = ?', [$role, (int)$id]);
    jsonResponse(['message' => '更新成功']);
}

function handleAdminDeleteUser($id) {
    $adminPayload = requireAdmin();
    if ((int)$id === $adminPayload['userId']) jsonError(400, '不能删除自己');
    dbRun('DELETE FROM users WHERE id = ?', [(int)$id]);
    jsonResponse(['message' => '删除成功']);
}

function handleAdminResetPassword($id) {
    requireAdmin();
    $newPass = substr(bin2hex(random_bytes(4)), 0, 8);
    $hash = password_hash($newPass, PASSWORD_BCRYPT);
    dbRun('UPDATE users SET password_hash = ? WHERE id = ?', [$hash, (int)$id]);
    jsonResponse(['message' => '密码已重置', 'newPassword' => $newPass]);
}

// ==================== 工具函数 ====================

function formatUser($user) {
    return [
        'id' => (int)$user['id'],
        'username' => $user['username'],
        'nickname' => $user['nickname'],
        'email' => $user['email'],
        'avatar_url' => $user['avatar_url'] ?? '',
        'bio' => $user['bio'] ?? '',
        'theme_name' => $user['theme_name'] ?? 'sakura',
        'accent_color' => $user['accent_color'] ?? '#ff6b9d',
        'is_public' => (int)($user['is_public'] ?? 1),
        'role' => $user['role'] ?? 'user'
    ];
}