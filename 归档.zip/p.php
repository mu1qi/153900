<?php
/**
 * 灰·韵 HUI·YUN — 页面路由器
 * 
 * 直接访问: https://153900.xyz/p.php?page=login
 * 或配置 Nginx 伪静态后使用: https://153900.xyz/login
 * 
 * 此文件也作为各页面 PHP 入口的公共包含
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';

// 初始化数据库 + 自动创建管理员
initDatabase();
cleanExpiredVerifications();
seedAdminAuto();

// 获取页面名称
$page = $_GET['page'] ?? '';

// 页面映射
$pages = [
    ''          => 'index.html',
    'home'      => 'index.html',
    'login'     => 'login.html',
    'dashboard' => 'dashboard.html',
    'terms'     => 'terms.html',
    'privacy'   => 'privacy.html',
    'about'     => 'about.html',
    'admin'     => 'admin.html',
    'qrcode'    => 'qrcode.html',
];

if (array_key_exists($page, $pages)) {
    $file = __DIR__ . '/' . $pages[$page];
    if (file_exists($file)) {
        readfile($file);
    } else {
        http_response_code(404);
        echo '页面文件不存在: ' . h($pages[$page]);
    }
    exit;
}

// 用户主页: p.php?page=profile&u=username
if ($page === 'profile') {
    $file = __DIR__ . '/profile.html';
    if (file_exists($file)) {
        readfile($file);
    } else {
        http_response_code(404);
        echo 'Not Found';
    }
    exit;
}

http_response_code(404);
echo 'Not Found';

function seedAdminAuto() {
    try {
        $existing = queryOne('SELECT id, role FROM users WHERE username = ?', [ADMIN_USERNAME]);
        if ($existing) {
            if ($existing['role'] !== 'admin') {
                dbRun('UPDATE users SET role = ? WHERE id = ?', ['admin', $existing['id']]);
            }
            return;
        }
        $hash = password_hash(ADMIN_PASSWORD, PASSWORD_BCRYPT);
        dbRun(
            'INSERT INTO users (username, nickname, email, password_hash, role, is_public) VALUES (?, ?, ?, ?, ?, ?)',
            [ADMIN_USERNAME, ADMIN_NICKNAME, ADMIN_EMAIL, $hash, 'admin', 0]
        );
    } catch (Exception $e) {}
}