<?php
/**
 * 灰·韵 HUI·YUN — 工具函数
 * 替代原来的 middleware/auth.js + services/email.js + services/logger.js
 */

require_once __DIR__ . '/config.php';

// ==================== JSON 响应 ====================

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonError($code, $message) {
    jsonResponse(['error' => $message], $code);
}

function getJsonInput() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return $data ?: [];
}

function getMethod() {
    return $_SERVER['REQUEST_METHOD'];
}

function getClientIP() {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    }
    return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}

// ==================== Token 认证 ====================

function generateToken($userId, $username, $role) {
    $payload = [
        'userId' => (int)$userId,
        'username' => $username,
        'role' => $role,
        'exp' => time() + JWT_EXPIRES
    ];
    $payloadJson = json_encode($payload);
    $payloadBase64 = rtrim(strtr(base64_encode($payloadJson), '+/', '-_'), '=');
    $signature = hash_hmac('sha256', $payloadBase64, JWT_SECRET);
    return $payloadBase64 . '.' . $signature;
}

function verifyToken($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 2) return null;
    list($payloadBase64, $signature) = $parts;
    $expectedSig = hash_hmac('sha256', $payloadBase64, JWT_SECRET);
    if (!hash_equals($expectedSig, $signature)) return null;
    $payload = json_decode(base64_decode(strtr($payloadBase64, '-_', '+/')), true);
    if (!$payload || (isset($payload['exp']) && $payload['exp'] < time())) return null;
    return $payload;
}

function getAuthToken() {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+(.+)$/i', $header, $m)) {
        return $m[1];
    }
    // 某些虚拟主机不传递 Authorization 头，尝试从 X-HTTP-Authorization 获取
    $alt = $_SERVER['HTTP_X_HTTP_AUTHORIZATION'] ?? $_SERVER['HTTP_X_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if ($alt && preg_match('/^Bearer\s+(.+)$/i', $alt, $m)) {
        return $m[1];
    }
    return null;
}

function requireAuth() {
    $token = getAuthToken();
    if (!$token) {
        jsonError(401, '请先登录');
    }
    $payload = verifyToken($token);
    if (!$payload) {
        jsonError(401, '登录已过期，请重新登录');
    }
    return $payload;
}

function requireAdmin() {
    $payload = requireAuth();
    if (($payload['role'] ?? 'user') !== 'admin') {
        jsonError(403, '需要管理员权限');
    }
    return $payload;
}

// ==================== 邮件 ====================

function generateCode() {
    return str_pad((string)mt_rand(0, 999999), 6, '0', STR_PAD_LEFT);
}

function sendVerificationEmail($email, $code, $type) {
    $subject = $type === 'register'
        ? '【灰·韵】邮箱验证码 - 注册账号'
        : '【灰·韵】邮箱验证码 - 登录';

    $html = '<div style="max-width:600px;margin:0 auto;padding:30px;font-family:\'PingFang SC\',\'Microsoft YaHei\',sans-serif;background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);border-radius:16px;color:#e0e0e0;">'
        . '<div style="text-align:center;margin-bottom:24px;">'
        . '<h1 style="color:#ff6b9d;font-size:28px;margin:0;">灰·韵 HUI·YUN</h1>'
        . '<p style="color:#999;font-size:14px;">你的个人聚合页平台</p></div>'
        . '<div style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:24px;text-align:center;">'
        . '<p style="font-size:16px;margin-bottom:16px;">'
        . ($type === 'register' ? '感谢注册灰·韵，你的验证码是：' : '你的登录验证码是：')
        . '</p>'
        . '<div style="font-size:36px;font-weight:bold;letter-spacing:8px;color:#ff6b9d;background:rgba(255,107,157,0.1);padding:12px 24px;border-radius:8px;display:inline-block;margin:12px 0;">'
        . $code . '</div>'
        . '<p style="color:#888;font-size:13px;margin-top:16px;">验证码10分钟内有效，请勿泄露给他人</p></div>'
        . '<div style="text-align:center;margin-top:24px;color:#666;font-size:12px;"><p>灰·韵 HUI·YUN © 2026</p></div></div>';

    // 如果配置了 SMTP，尝试发送
    if (SMTP_HOST && SMTP_USER && SMTP_PASS) {
        return sendSMTP($email, $subject, $html);
    }

    // 降级模式：验证码输出到服务器日志
    error_log("[邮件] 收件人: {$email} | 验证码: {$code} | 类型: {$type}");
    return true; // 总是返回成功，前端会收到验证码已发送
}

function sendSMTP($to, $subject, $html) {
    $host = SMTP_HOST;
    $port = (int)SMTP_PORT;
    $user = SMTP_USER;
    $pass = SMTP_PASS;
    $from = SMTP_FROM ?: $user;

    try {
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=utf-8\r\n";
        $headers .= "From: {$from}\r\n";
        $headers .= "To: {$to}\r\n";

        // 使用 PHP mail() 作为 fallback（虚拟主机通常已配置好 sendmail）
        if (SMTP_SECURE === 'false' || true) {
            return mail($to, $subject, $html, $headers);
        }

        return false;
    } catch (Exception $e) {
        error_log("[邮件] 发送失败: " . $e->getMessage());
        return false;
    }
}

// ==================== 安全过滤 ====================

function h($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

// ==================== 验证码 ====================

function verifyEmailCode($email, $code, $type) {
    $row = queryOne(
        "SELECT * FROM email_verifications WHERE email = ? AND code = ? AND type = ? AND expires_at > NOW() AND used = 0 ORDER BY id DESC LIMIT 1",
        [$email, $code, $type]
    );
    if (!$row) return null;
    dbRun("UPDATE email_verifications SET used = 1 WHERE id = ?", [$row['id']]);
    return $row;
}

function checkRateLimit($email) {
    $recent = queryOne(
        "SELECT id FROM email_verifications WHERE email = ? AND created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)",
        [$email]
    );
    return $recent ? false : true;
}