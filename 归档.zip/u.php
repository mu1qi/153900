<?php
/**
 * 用户主页入口
 * 访问: https://153900.xyz/u.php?u=username
 * 配置 Nginx 伪静态后可使用: https://153900.xyz/username
 */
$_GET['page'] = 'profile';
require_once __DIR__ . '/p.php';