/* ========================================
   灰·韵 HUI·YUN - 通用工具函数
   ======================================== */

const API_BASE = '/api.php?path=';

// --- Toast 通知 ---
function showToast(message, type = 'info') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// --- API 请求 ---
async function api(path, options = {}) {
  const token = localStorage.getItem('huiyun_token');
  const headers = { ...options.headers };
  // 仅 JSON 请求设置 Content-Type，FormData 上传由浏览器自动设置
  if (!options.body || !(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
    headers['X-Authorization'] = `Bearer ${token}`; // PHP CGI 兼容
  }

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.error || '请求失败');
  }
  return data;
}

// --- 认证 ---
function getToken() {
  return localStorage.getItem('huiyun_token');
}

function getCurrentUser() {
  try {
    const user = localStorage.getItem('huiyun_user');
    return user ? JSON.parse(user) : null;
  } catch { return null; }
}

function setAuth(token, user) {
  localStorage.setItem('huiyun_token', token);
  localStorage.setItem('huiyun_user', JSON.stringify(user));
}

function clearAuth() {
  localStorage.removeItem('huiyun_token');
  localStorage.removeItem('huiyun_user');
}

function isLoggedIn() {
  return !!getToken();
}

function requireAuth() {
  if (!isLoggedIn()) {
    window.location.href = '/login.php';
    return false;
  }
  return true;
}

// --- 页面 URL 辅助 ---
function pageUrl(page) {
  return '/' + page + '.php';
}

function profileUrl(username) {
  return '/u.php?u=' + encodeURIComponent(username);
}

// --- 更新导航栏 ---
function updateNavbar() {
  const navActions = document.querySelector('.navbar-actions');
  if (!navActions) return;

  const user = getCurrentUser();
  if (user) {
    navActions.innerHTML = `
      <a href="/" class="btn btn-glass btn-sm">发现</a>
      <a href="/dashboard.php" class="btn btn-glass btn-sm">管理</a>
      <a href="${profileUrl(user.username)}" class="btn btn-glass btn-sm">我的主页</a>
      <button class="btn btn-glass btn-sm" onclick="doLogout()">退出</button>
    `;
  } else {
    navActions.innerHTML = `
      <a href="/" class="btn btn-glass btn-sm">发现</a>
      <a href="/login.php" class="btn btn-primary btn-sm">登录 / 注册</a>
    `;
  }
}

function doLogout() {
  clearAuth();
  window.location.href = '/';
}

// --- 樱花飘落动画 ---
function initSakuraPetals() {
  const container = document.createElement('div');
  container.className = 'sakura-petals';
  document.body.appendChild(container);

  for (let i = 0; i < 15; i++) {
    const petal = document.createElement('div');
    petal.className = 'petal';
    petal.style.left = `${Math.random() * 100}%`;
    petal.style.animationDuration = `${8 + Math.random() * 10}s`;
    petal.style.animationDelay = `${Math.random() * 10}s`;
    petal.style.fontSize = `${12 + Math.random() * 12}px`;
    container.appendChild(petal);
  }
}

// --- 主题管理 ---
function applyTheme(themeName) {
  document.documentElement.setAttribute('data-theme', themeName);
  localStorage.setItem('huiyun_theme', themeName);
}

function loadTheme() {
  const saved = localStorage.getItem('huiyun_theme');
  if (saved) {
    document.documentElement.setAttribute('data-theme', saved);
  }
}

// --- 复制到剪贴板 ---
function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    showToast('已复制到剪贴板', 'success');
  }).catch(() => {
    showToast('复制失败', 'error');
  });
}

// --- 格式化数字 ---
function formatNumber(num) {
  if (num >= 10000) return (num / 10000).toFixed(1) + 'w';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
  return String(num);
}

// --- 时间格式化 ---
function formatDate(dateStr) {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = now - date;
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));

  if (days === 0) return '今天';
  if (days === 1) return '昨天';
  if (days < 7) return `${days}天前`;
  if (days < 30) return `${Math.floor(days / 7)}周前`;
  if (days < 365) return `${Math.floor(days / 30)}个月前`;
  return `${Math.floor(days / 365)}年前`;
}

// --- 初始化 ---
document.addEventListener('DOMContentLoaded', () => {
  loadTheme();
  updateNavbar();

  // 自动刷新 token（如果存在）
  if (isLoggedIn()) {
    api('auth/me').then(data => {
      localStorage.setItem('huiyun_user', JSON.stringify(data.user));
      updateNavbar();
    }).catch(err => {
      if (err.message === '登录已过期，请重新登录') {
        clearAuth();
        updateNavbar();
      }
    });
  }
});