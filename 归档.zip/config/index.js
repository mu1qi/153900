/**
 * 灰·韵 HUI·YUN — 集中配置
 * 所有环境变量在此统一读取，提供默认值
 */

const path = require('path');

const isProduction = process.env.NODE_ENV === 'production';

module.exports = {
  // 运行环境
  isProduction,
  port: parseInt(process.env.PORT) || 3000,

  // 站点
  siteUrl: process.env.SITE_URL || 'https://153900.xyz',

  // JWT
  jwtSecret: process.env.JWT_SECRET || 'huiyun_secret_key_change_in_production',
  jwtExpiresIn: '30d',

  // MySQL
  db: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || '',
    database: process.env.DB_NAME || 'huiyun',
    connectionLimit: 10,
    charset: 'utf8mb4'
  },

  // SMTP 邮件
  smtp: {
    host: process.env.SMTP_HOST || '',
    port: parseInt(process.env.SMTP_PORT) || 465,
    secure: process.env.SMTP_SECURE !== 'false',
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
    from: process.env.SMTP_FROM || process.env.SMTP_USER || ''
  },

  // 上传
  upload: {
    avatarMaxSize: 5 * 1024 * 1024,    // 5MB
    bgMaxSize: 10 * 1024 * 1024,       // 10MB
    allowedTypes: ['.jpg', '.jpeg', '.png', '.gif', '.webp'],
    dir: path.join(__dirname, '..', 'uploads')
  },

  // 速率限制
  rateLimit: {
    api: { windowMs: 15 * 60 * 1000, max: 200 },
    auth: { windowMs: 15 * 60 * 1000, max: 20 }
  },

  // 管理员
  admin: {
    username: 'admin',
    nickname: '灰·韵管理员',
    email: 'admin@153900.xyz',
    password: 'admin123456'
  },

  // 日志
  logDir: path.join(__dirname, '..', 'logs')
};