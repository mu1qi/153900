# 灰·韵 HUI·YUN 部署指南

## 一、项目结构

```
huiyun/
├── server.js              # 主服务入口
├── database.js            # MySQL 数据库层
├── seed.js                # 管理员账号种子脚本
├── package.json           # 依赖与脚本
├── .env                   # 环境变量（需手动配置）
├── ecosystem.config.js    # PM2 进程管理配置
├── nginx.conf.example     # Nginx 反向代理配置模板
├── config/
│   └── index.js           # 集中配置（读取 .env）
├── middleware/
│   └── auth.js            # JWT 认证中间件
├── services/
│   ├── email.js           # SMTP 邮件服务
│   └── logger.js          # 日志服务
├── routes/
│   ├── auth.js            # 认证（注册/登录/验证码）
│   ├── user.js            # 用户资料/社交链接/音乐/主题
│   ├── discover.js        # 发现页/点赞
│   ├── upload.js          # 文件上传/二维码
│   └── admin.js           # 管理后台 API
├── public/                # 前端静态文件
│   ├── index.html         # 发现页（首页）
│   ├── login.html         # 登录/注册
│   ├── dashboard.html     # 用户管理后台
│   ├── profile.html       # 用户公开主页
│   ├── admin.html         # 管理后台
│   ├── qrcode.html        # 二维码页面
│   ├── css/style.css      # 全局样式
│   ├── js/common.js       # 通用工具
│   └── assets/            # 静态资源
├── uploads/               # 用户上传文件
│   ├── avatars/
│   └── backgrounds/
└── logs/                  # 运行日志（自动生成）
```

## 二、部署到 VPS / 虚拟主机

### 1. 环境要求

- Node.js >= 18
- MySQL >= 5.7（或 MariaDB >= 10.2）
- PM2（推荐，用于进程守护）
- Nginx（推荐，用于反向代理）

### 2. 上传项目

```bash
# 通过 SFTP 将整个 huiyun 文件夹上传到服务器
# 推荐路径: /home/用户名/huiyun 或 /var/www/huiyun
```

### 3. 安装 Node.js（Debian 13）

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v  # 确认 >= 18
```

### 4. 安装 MySQL 并创建数据库

```bash
# 安装 MySQL
sudo apt-get install -y mysql-server
sudo mysql_secure_installation

# 创建数据库和用户
sudo mysql -u root -p
```

```sql
CREATE DATABASE huiyun CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'huiyun'@'localhost' IDENTIFIED BY '你的密码';
GRANT ALL PRIVILEGES ON huiyun.* TO 'huiyun'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 5. 安装依赖

```bash
cd /path/to/huiyun
npm install
```

### 6. 配置环境变量

```bash
cp .env.example .env
nano .env
```

必须修改的内容：
- `DB_PASS`：MySQL 密码
- `JWT_SECRET`：改为随机字符串，运行 `openssl rand -hex 32` 生成
- `SMTP_PASS`：邮箱密码（可选，不填则验证码输出到日志）
- `SITE_URL`：你的域名

### 7. 配置 SMTP 邮箱（可选）

如需邮件验证码功能，配置任意 SMTP 邮箱（QQ邮箱、163邮箱、企业邮箱等）。

以 QQ 邮箱为例：
1. 登录 QQ 邮箱 → 设置 → 账户 → POP3/SMTP 服务 → 开启
2. 获取授权码
3. 填入 `.env`：
```
SMTP_HOST=smtp.qq.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=你的QQ号@qq.com
SMTP_PASS=授权码
SMTP_FROM=灰·韵 HUI·YUN <你的QQ号@qq.com>
```

### 8. 启动服务

```bash
# 测试运行
npm run dev

# 生产环境直接运行
npm run prod

# 使用 PM2 后台运行（推荐）
npm install -g pm2
npm run pm2:start
pm2 save
pm2 startup  # 设置开机自启
```

PM2 常用命令：
```bash
npm run pm2:status   # 查看状态
npm run pm2:logs     # 查看日志
npm run pm2:restart  # 重启
npm run pm2:stop     # 停止
```

### 9. 配置 Nginx 反向代理

```bash
# 复制配置模板
sudo cp nginx.conf.example /etc/nginx/sites-available/huiyun

# 修改路径（将 /path/to/huiyun 改为实际路径）
sudo nano /etc/nginx/sites-available/huiyun

# 启用站点
sudo ln -s /etc/nginx/sites-available/huiyun /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 10. 配置 SSL（Let's Encrypt 免费证书）

```bash
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d 153900.xyz -d www.153900.xyz
```

## 三、虚拟主机（cPanel / DirectAdmin）

如果虚拟主机面板支持 Node.js 应用：

1. 在控制面板找到 "Setup Node.js App"
2. 应用路径：`huiyun/server.js`
3. 端口：面板分配的端口（不是 3000）
4. 确保 MySQL 数据库已创建，并在面板中设置环境变量
5. 面板会自动配置反向代理

## 四、管理员账号

服务首次启动时自动创建管理员账号：

| 字段 | 值 |
|------|------|
| 用户名 | `admin` |
| 邮箱 | `admin@153900.xyz` |
| 密码 | `admin123456` |

**首次登录后请立即修改密码！** 可通过修改 `config/index.js` 中的 `admin` 配置来更改默认值。

## 五、API 接口列表

| 方法 | 路径 | 鉴权 | 说明 |
|------|------|------|------|
| GET | /health | - | 健康检查 |
| POST | /api/auth/send-code | - | 发送验证码 |
| POST | /api/auth/register | - | 注册 |
| POST | /api/auth/login | - | 密码登录 |
| POST | /api/auth/login/send-code | - | 发送登录验证码 |
| POST | /api/auth/login/verify | - | 验证码登录 |
| GET | /api/auth/me | 用户 | 获取当前用户 |
| PUT | /api/user/profile | 用户 | 更新资料 |
| PUT | /api/user/social-links | 用户 | 更新社交链接 |
| PUT | /api/user/music | 用户 | 更新音乐 |
| PUT | /api/user/theme | 用户 | 更新主题 |
| GET | /api/user/profile/:username | - | 获取用户主页 |
| POST | /api/user/visit/:username | - | 记录访问 |
| GET | /api/discover | - | 发现页 |
| POST | /api/discover/like/:username | - | 点赞 |
| POST | /api/upload/avatar | 用户 | 上传头像 |
| POST | /api/upload/background | 用户 | 上传背景 |
| GET | /api/upload/qrcode/:username | - | 生成二维码 |
| GET | /api/admin/stats | 管理员 | 仪表盘概览 |
| GET | /api/admin/users | 管理员 | 用户列表 |
| GET | /api/admin/users/:id | 管理员 | 用户详情 |
| PUT | /api/admin/users/:id/toggle-public | 管理员 | 切换公开 |
| PUT | /api/admin/users/:id/role | 管理员 | 设置角色 |
| DELETE | /api/admin/users/:id | 管理员 | 删除用户 |
| POST | /api/admin/users/:id/reset-password | 管理员 | 重置密码 |

## 六、数据备份

```bash
# 备份 MySQL 数据库
mysqldump -u root -p huiyun > huiyun_backup_$(date +%Y%m%d).sql

# 备份上传文件
tar -czf uploads_backup_$(date +%Y%m%d).tar.gz uploads/

# 建议设置 crontab 定时备份
# 0 3 * * * /path/to/backup.sh
```

## 七、常见问题

**Q: 验证码没有发送到邮箱？**
A: 未配置 SMTP 时验证码会输出到控制台（`npm run pm2:logs` 查看）。配置 SMTP 后检查 `.env` 中的用户名密码是否正确。

**Q: 忘记管理员密码？**
A: 删除数据库中 admin 用户，重启服务会自动重新创建。

**Q: 如何更新代码？**
A: `git pull`（如使用 Git）或重新上传文件，然后 `npm run pm2:restart`。

**Q: 512MB 内存够用吗？**
A: 够用。Node.js 进程限制 300MB 内存（`ecosystem.config.js` 中配置），MySQL 建议使用 1-2 的 `connectionLimit`。