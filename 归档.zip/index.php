<?php
/**
 * 灰·韵 HUI·YUN — 前端路由
 * 负责分发 HTML 页面和用户主页
 * 
 * 通过 .htaccess 重写：所有非文件请求 → index.php?path=xxx
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';

// 初始化数据库
initDatabase();

// 清理过期验证码
cleanExpiredVerifications();

// 自动创建管理员账号
seedAdmin();

$path = $_GET['path'] ?? '';
$path = trim($path, '/');

// 静态文件有 Apache 直接 serve，这里只处理 HTML 页面路由

$pages = [
    ''          => 'index.html',
    'login'     => 'login.html',
    'dashboard' => 'dashboard.html',
    'terms'     => 'terms.html',
    'privacy'   => 'privacy.html',
    'about'     => 'about.html',
    'admin'     => 'admin.html',
    'qrcode'    => 'qrcode.html',
];

// 匹配 /qrcode/username
if (preg_match('#^qrcode/(.+)$#', $path, $m)) {
    serveFile('qrcode.html');
}

// 已知页面
if (array_key_exists($path, $pages)) {
    serveFile($pages[$path]);
}

// 根路径
if ($path === '') {
    serveFile('index.html');
}

// 排除非用户名路径
if (in_array($path, ['css', 'js', 'assets', 'uploads', 'api', 'health', 'favicon.ico'])) {
    http_response_code(404);
    echo 'Not Found';
    exit;
}

// 排除带扩展名的请求（静态文件）
if (strpos($path, '.') !== false) {
    http_response_code(404);
    echo 'Not Found';
    exit;
}

// 用户主页
serveFile('profile.html');

// ==================== 工具函数 ====================

function serveFile($filename) {
    $file = __DIR__ . '/' . $filename;
    if (file_exists($file)) {
        readfile($file);
    } else {
        http_response_code(404);
        echo 'Not Found';
    }
    exit;
}

function seedAdmin() {
    try {
        $existing = queryOne('SELECT id, role FROM users WHERE username = ?', [ADMIN_USERNAME]);
        if ($existing) {
            if ($existing['role'] !== 'admin') {
                dbRun('UPDATE users SET role = ? WHERE id = ?', ['admin', $existing['id']]);
            }
            return;
        }
        $hash = password_hash(ADMIN_PASSWORD, PASSWORD_BCRYPT);
        dbRun(
            'INSERT INTO users (username, nickname, email, password_hash, role, is_public) VALUES (?, ?, ?, ?, ?, ?)',
            [ADMIN_USERNAME, ADMIN_NICKNAME, ADMIN_EMAIL, $hash, 'admin', 0]
        );
    } catch (Exception $e) {
        // 静默失败，首次访问时数据库可能还未配置
    }
}