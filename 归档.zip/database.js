const mysql = require('mysql2/promise');
const config = require('./config');

let pool = null;

// 创建 MySQL 连接池
async function createPool() {
  pool = mysql.createPool({
    host: config.db.host,
    port: config.db.port,
    user: config.db.user,
    password: config.db.password,
    database: config.db.database,
    waitForConnections: true,
    connectionLimit: config.db.connectionLimit,
    queueLimit: 0,
    charset: config.db.charset
  });
  return pool;
}

// 初始化数据库表
async function initDatabase() {
  await createPool();

  const tables = [
    `CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(20) NOT NULL UNIQUE,
      nickname VARCHAR(30) NOT NULL,
      email VARCHAR(100) NOT NULL UNIQUE,
      password_hash VARCHAR(255) NOT NULL,
      role VARCHAR(10) DEFAULT 'user',
      avatar_url VARCHAR(255) DEFAULT '',
      bio TEXT DEFAULT '',
      is_public TINYINT(1) DEFAULT 1,
      custom_bg_url VARCHAR(255) DEFAULT '',
      theme_name VARCHAR(20) DEFAULT 'sakura',
      accent_color VARCHAR(10) DEFAULT '#ff6b9d',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_username (username),
      INDEX idx_email (email),
      INDEX idx_role (role)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS email_verifications (
      id INT AUTO_INCREMENT PRIMARY KEY,
      email VARCHAR(100) NOT NULL,
      code VARCHAR(10) NOT NULL,
      type VARCHAR(20) NOT NULL DEFAULT 'register',
      expires_at DATETIME NOT NULL,
      used TINYINT(1) DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS social_links (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      platform VARCHAR(30) NOT NULL,
      platform_label VARCHAR(30) NOT NULL,
      url VARCHAR(500) NOT NULL,
      icon_svg TEXT DEFAULT '',
      sort_order INT DEFAULT 0,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      INDEX idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS music_settings (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL UNIQUE,
      type VARCHAR(20) DEFAULT 'netease',
      music_url VARCHAR(500) DEFAULT '',
      music_id TEXT DEFAULT '',
      title VARCHAR(100) DEFAULT '',
      artist VARCHAR(100) DEFAULT '',
      autoplay TINYINT(1) DEFAULT 0,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS likes (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      liked_by_ip VARCHAR(45) NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      UNIQUE KEY uk_user_ip (user_id, liked_by_ip),
      INDEX idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS visit_stats (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      visitor_ip VARCHAR(45) NOT NULL,
      visited_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      INDEX idx_user (user_id),
      INDEX idx_visited (user_id, visitor_ip, visited_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  ];

  for (const sql of tables) {
    await pool.execute(sql);
  }

  // 迁移：为已有数据库添加 role 列（兼容旧版本）
  try {
    await pool.execute(`ALTER TABLE users ADD COLUMN role VARCHAR(10) DEFAULT 'user'`);
    console.log('[数据库] 迁移：已添加 role 列');
  } catch (e) {
    // 列已存在，忽略
  }
  try {
    await pool.execute(`ALTER TABLE users ADD INDEX idx_role (role)`);
  } catch (e) {
    // 索引已存在，忽略
  }

  console.log('[数据库] MySQL 表初始化完成');
  return pool;
}

// 获取连接池
function getPool() {
  if (!pool) throw new Error('数据库未初始化，请先调用 initDatabase()');
  return pool;
}

// 查询多条
async function queryAll(sql, params = []) {
  const [rows] = await getPool().execute(sql, params);
  return rows;
}

// 查询单条
async function queryOne(sql, params = []) {
  const rows = await queryAll(sql, params);
  return rows.length > 0 ? rows[0] : null;
}

// 执行写操作
async function run(sql, params = []) {
  const [result] = await getPool().execute(sql, params);
  return {
    lastInsertRowid: result.insertId || 0,
    changes: result.affectedRows || 0
  };
}

// 清理过期验证码
async function cleanExpiredVerifications() {
  try {
    await run("DELETE FROM email_verifications WHERE expires_at < NOW()");
  } catch (e) {
    console.error('[数据库] 清理验证码失败:', e.message);
  }
}

// 关闭连接池
async function closePool() {
  if (pool) {
    await pool.end();
    pool = null;
  }
}

module.exports = {
  initDatabase,
  getPool,
  queryAll,
  queryOne,
  run,
  cleanExpiredVerifications,
  closePool
};