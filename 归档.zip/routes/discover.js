const express = require('express');
const { queryAll, queryOne, run } = require('../database');

const router = express.Router();

// 发现页
router.get('/', async (req, res) => {
  const { sort = 'likes', page = 1, limit = 20 } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  let orderBy = 'like_count DESC';
  if (sort === 'newest') orderBy = 'u.created_at DESC';
  else if (sort === 'visits') orderBy = 'visit_count DESC';

  const users = await queryAll(`
    SELECT 
      u.id, u.username, u.nickname, u.avatar_url, u.bio, u.theme_name, u.accent_color, u.created_at,
      COALESCE(l.like_count, 0) as like_count, COALESCE(v.visit_count, 0) as visit_count
    FROM users u
    LEFT JOIN (SELECT user_id, COUNT(*) as like_count FROM likes GROUP BY user_id) l ON u.id = l.user_id
    LEFT JOIN (SELECT user_id, COUNT(*) as visit_count FROM visit_stats GROUP BY user_id) v ON u.id = v.user_id
    WHERE u.is_public = 1
    ORDER BY ${orderBy}
    LIMIT ? OFFSET ?
  `, [parseInt(limit), offset]);

  const totalRow = await queryOne('SELECT COUNT(*) as count FROM users WHERE is_public = 1');
  const total = totalRow?.count || 0;

  res.json({
    users,
    pagination: {
      page: parseInt(page),
      limit: parseInt(limit),
      total,
      totalPages: Math.ceil(total / parseInt(limit))
    }
  });
});

// 点赞
router.post('/like/:username', async (req, res) => {
  const { username } = req.params;
  const user = await queryOne('SELECT id FROM users WHERE username = ? AND is_public = 1', [username]);
  if (!user) return res.status(404).json({ error: '用户不存在' });

  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const existing = await queryOne('SELECT id FROM likes WHERE user_id = ? AND liked_by_ip = ?', [user.id, ip]);

  if (existing) {
    await run('DELETE FROM likes WHERE id = ?', [existing.id]);
    const likeCount = (await queryOne('SELECT COUNT(*) as count FROM likes WHERE user_id = ?', [user.id]))?.count || 0;
    return res.json({ liked: false, likeCount });
  }

  try {
    await run('INSERT INTO likes (user_id, liked_by_ip) VALUES (?, ?)', [user.id, ip]);
  } catch (e) {
    // 唯一键冲突，视为已点赞
    const likeCount = (await queryOne('SELECT COUNT(*) as count FROM likes WHERE user_id = ?', [user.id]))?.count || 0;
    return res.json({ liked: true, likeCount });
  }

  const likeCount = (await queryOne('SELECT COUNT(*) as count FROM likes WHERE user_id = ?', [user.id]))?.count || 0;
  res.json({ liked: true, likeCount });
});

// 检查是否已点赞
router.get('/like/:username/check', async (req, res) => {
  const { username } = req.params;
  const user = await queryOne('SELECT id FROM users WHERE username = ?', [username]);
  if (!user) return res.status(404).json({ error: '用户不存在' });

  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const existing = await queryOne('SELECT id FROM likes WHERE user_id = ? AND liked_by_ip = ?', [user.id, ip]);
  res.json({ liked: !!existing });
});

module.exports = router;