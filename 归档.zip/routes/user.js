const express = require('express');
const { queryAll, queryOne, run } = require('../database');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

// 更新个人资料
router.put('/profile', authMiddleware, async (req, res) => {
  const { nickname, bio, is_public } = req.body;
  if (nickname !== undefined && (!nickname || nickname.trim().length === 0)) {
    return res.status(400).json({ error: '昵称不能为空' });
  }

  const updates = [];
  const params = [];
  if (nickname !== undefined) { updates.push('nickname = ?'); params.push(nickname); }
  if (bio !== undefined) { updates.push('bio = ?'); params.push(bio); }
  if (is_public !== undefined) { updates.push('is_public = ?'); params.push(is_public ? 1 : 0); }
  if (updates.length === 0) return res.status(400).json({ error: '没有需要更新的内容' });

  params.push(req.userId);
  await run(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, params);
  const user = await queryOne('SELECT id, username, nickname, email, avatar_url, bio, theme_name, accent_color, custom_bg_url, is_public FROM users WHERE id = ?', [req.userId]);
  res.json({ message: '更新成功', user });
});

// 更新社交链接
router.put('/social-links', authMiddleware, async (req, res) => {
  const { links } = req.body;
  if (!Array.isArray(links)) return res.status(400).json({ error: '数据格式错误' });

  // 使用事务确保原子性
  const pool = require('../database').getPool();
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    await conn.execute('DELETE FROM social_links WHERE user_id = ?', [req.userId]);
    for (let i = 0; i < links.length; i++) {
      if (links[i].platform && links[i].url) {
        await conn.execute(
          'INSERT INTO social_links (user_id, platform, platform_label, url, icon_svg, sort_order) VALUES (?, ?, ?, ?, ?, ?)',
          [req.userId, links[i].platform, links[i].platform_label || links[i].platform, links[i].url, links[i].icon_svg || '', i]
        );
      }
    }
    await conn.commit();
  } catch (err) {
    await conn.rollback();
    conn.release();
    return res.status(500).json({ error: '保存失败' });
  }
  conn.release();

  const updated = await queryAll('SELECT * FROM social_links WHERE user_id = ? ORDER BY sort_order ASC', [req.userId]);
  res.json({ message: '更新成功', links: updated });
});

// 更新音乐设置
router.put('/music', authMiddleware, async (req, res) => {
  const { type, music_url, music_id, title, artist, autoplay } = req.body;
  const existing = await queryOne('SELECT * FROM music_settings WHERE user_id = ?', [req.userId]);

  if (existing) {
    await run(
      'UPDATE music_settings SET type = ?, music_url = ?, music_id = ?, title = ?, artist = ?, autoplay = ? WHERE user_id = ?',
      [
        type || existing.type,
        music_url !== undefined ? music_url : existing.music_url,
        music_id !== undefined ? music_id : existing.music_id,
        title !== undefined ? title : existing.title,
        artist !== undefined ? artist : existing.artist,
        autoplay !== undefined ? (autoplay ? 1 : 0) : existing.autoplay,
        req.userId
      ]
    );
  } else {
    await run(
      'INSERT INTO music_settings (user_id, type, music_url, music_id, title, artist, autoplay) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [req.userId, type || 'netease', music_url || '', music_id || '', title || '', artist || '', autoplay ? 1 : 0]
    );
  }

  const music = await queryOne('SELECT * FROM music_settings WHERE user_id = ?', [req.userId]);
  res.json({ message: '更新成功', music });
});

// 更新主题设置
router.put('/theme', authMiddleware, async (req, res) => {
  const { theme_name, accent_color, custom_bg_url } = req.body;
  const updates = [];
  const params = [];
  if (theme_name !== undefined) { updates.push('theme_name = ?'); params.push(theme_name); }
  if (accent_color !== undefined) { updates.push('accent_color = ?'); params.push(accent_color); }
  if (custom_bg_url !== undefined) { updates.push('custom_bg_url = ?'); params.push(custom_bg_url); }
  if (updates.length === 0) return res.status(400).json({ error: '没有需要更新的内容' });

  params.push(req.userId);
  await run(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, params);
  const user = await queryOne('SELECT id, username, theme_name, accent_color, custom_bg_url FROM users WHERE id = ?', [req.userId]);
  res.json({ message: '更新成功', user });
});

// 获取公开用户主页
router.get('/profile/:username', async (req, res) => {
  const { username } = req.params;
  const user = await queryOne(
    'SELECT id, username, nickname, avatar_url, bio, theme_name, accent_color, custom_bg_url, is_public, created_at FROM users WHERE username = ?',
    [username]
  );
  if (!user) return res.status(404).json({ error: '用户不存在' });
  if (!user.is_public) return res.status(403).json({ error: '该用户已隐藏主页' });

  const socialLinks = await queryAll('SELECT * FROM social_links WHERE user_id = ? ORDER BY sort_order ASC', [user.id]);
  const music = await queryOne('SELECT * FROM music_settings WHERE user_id = ?', [user.id]);
  const likeCount = (await queryOne('SELECT COUNT(*) as count FROM likes WHERE user_id = ?', [user.id]))?.count || 0;
  const visitCount = (await queryOne('SELECT COUNT(*) as count FROM visit_stats WHERE user_id = ?', [user.id]))?.count || 0;

  res.json({ user, socialLinks, music: music || null, likeCount, visitCount });
});

// 记录访问
router.post('/visit/:username', async (req, res) => {
  const { username } = req.params;
  const user = await queryOne('SELECT id FROM users WHERE username = ? AND is_public = 1', [username]);
  if (!user) return res.status(404).json({ error: '用户不存在' });

  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const recent = await queryOne(
    "SELECT id FROM visit_stats WHERE user_id = ? AND visitor_ip = ? AND visited_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)",
    [user.id, ip]
  );
  if (!recent) {
    await run('INSERT INTO visit_stats (user_id, visitor_ip) VALUES (?, ?)', [user.id, ip]);
  }
  res.json({ ok: true });
});

module.exports = router;