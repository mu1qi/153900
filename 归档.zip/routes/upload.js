const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const QRCode = require('qrcode');
const { run } = require('../database');
const config = require('../config');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

const uploadsDir = config.upload.dir;
const avatarsDir = path.join(uploadsDir, 'avatars');
const backgroundsDir = path.join(uploadsDir, 'backgrounds');
[avatarsDir, backgroundsDir].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

const avatarStorage = multer.diskStorage({
  destination: avatarsDir,
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `avatar_${req.userId}_${Date.now()}${ext}`);
  }
});

const backgroundStorage = multer.diskStorage({
  destination: backgroundsDir,
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `bg_${req.userId}_${Date.now()}${ext}`);
  }
});

const fileFilter = (req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase();
  cb(null, config.upload.allowedTypes.includes(ext));
};

const uploadAvatar = multer({ storage: avatarStorage, fileFilter, limits: { fileSize: config.upload.avatarMaxSize } });
const uploadBackground = multer({ storage: backgroundStorage, fileFilter, limits: { fileSize: config.upload.bgMaxSize } });

router.post('/avatar', authMiddleware, uploadAvatar.single('avatar'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: '请选择图片' });
  const url = `/uploads/avatars/${req.file.filename}`;
  await run('UPDATE users SET avatar_url = ? WHERE id = ?', [url, req.userId]);
  res.json({ message: '上传成功', url });
});

router.post('/background', authMiddleware, uploadBackground.single('background'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: '请选择图片' });
  const url = `/uploads/backgrounds/${req.file.filename}`;
  await run('UPDATE users SET custom_bg_url = ? WHERE id = ?', [url, req.userId]);
  res.json({ message: '上传成功', url });
});

router.get('/qrcode/:username', async (req, res) => {
  const { username } = req.params;
  try {
    const url = `${config.siteUrl}/${username}`;
    const qrDataUrl = await QRCode.toDataURL(url, {
      width: 400, margin: 2,
      color: { dark: '#ff6b9d', light: '#ffffff' },
      errorCorrectionLevel: 'H'
    });
    if (req.query.download === '1') {
      const base64Data = qrDataUrl.replace(/^data:image\/png;base64,/, '');
      const buffer = Buffer.from(base64Data, 'base64');
      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Content-Disposition', `attachment; filename="huiyun_${username}.png"`);
      return res.send(buffer);
    }
    res.json({ qrcode: qrDataUrl, url });
  } catch (err) {
    res.status(500).json({ error: '生成二维码失败' });
  }
});

module.exports = router;