const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { queryAll, queryOne, run } = require('../database');
const config = require('../config');
const emailService = require('../services/email');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

const router = express.Router();
const JWT_SECRET = config.jwtSecret;

// 发送验证码
router.post('/send-code', async (req, res) => {
  const { email, type } = req.body;
  if (!email) return res.status(400).json({ error: '请输入邮箱' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: '邮箱格式不正确' });

  const recent = await queryOne(
    "SELECT id FROM email_verifications WHERE email = ? AND created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)",
    [email]
  );
  if (recent) return res.status(429).json({ error: '请60秒后再试' });

  const code = emailService.generateCode();
  await run(
    "INSERT INTO email_verifications (email, code, type, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE))",
    [email, code, type || 'register']
  );
  await emailService.sendVerification(email, code, type || 'register');
  res.json({ message: '验证码已发送', mode: emailService.getMode() });
});

// 注册
router.post('/register', async (req, res) => {
  const { username, nickname, email, password, code } = req.body;
  if (!username || !nickname || !email || !password || !code) return res.status(400).json({ error: '请填写所有字段' });
  if (!/^[a-zA-Z0-9_\u4e00-\u9fa5]{2,20}$/.test(username)) return res.status(400).json({ error: '用户名需2-20位字母、数字或中文' });
  if (password.length < 6) return res.status(400).json({ error: '密码至少6位' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: '邮箱格式不正确' });

  const verification = await queryOne(
    "SELECT * FROM email_verifications WHERE email = ? AND code = ? AND type = 'register' AND expires_at > NOW() AND used = 0 ORDER BY id DESC LIMIT 1",
    [email, code]
  );
  if (!verification) return res.status(400).json({ error: '验证码错误或已过期' });

  if (await queryOne('SELECT id FROM users WHERE username = ?', [username])) return res.status(400).json({ error: '用户名已被注册' });
  if (await queryOne('SELECT id FROM users WHERE email = ?', [email])) return res.status(400).json({ error: '邮箱已被注册' });

  await run('UPDATE email_verifications SET used = 1 WHERE id = ?', [verification.id]);

  const passwordHash = bcrypt.hashSync(password, 10);
  const result = await run(
    'INSERT INTO users (username, nickname, email, password_hash) VALUES (?, ?, ?, ?)',
    [username, nickname, email, passwordHash]
  );

  const token = jwt.sign({ userId: result.lastInsertRowid, username, role: 'user' }, JWT_SECRET, { expiresIn: config.jwtExpiresIn });
  res.json({
    message: '注册成功',
    token,
    user: { id: result.lastInsertRowid, username, nickname, email, avatar_url: '', bio: '', theme_name: 'sakura', accent_color: '#ff6b9d', role: 'user' }
  });
});

// 发送登录验证码
router.post('/login/send-code', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: '请输入邮箱' });
  if (!(await queryOne('SELECT id FROM users WHERE email = ?', [email]))) return res.status(400).json({ error: '该邮箱未注册' });

  const code = emailService.generateCode();
  await run("INSERT INTO email_verifications (email, code, type, expires_at) VALUES (?, ?, 'login', DATE_ADD(NOW(), INTERVAL 10 MINUTE))", [email, code]);
  await emailService.sendVerification(email, code, 'login');
  res.json({ message: '验证码已发送', mode: emailService.getMode() });
});

// 验证码登录
router.post('/login/verify', async (req, res) => {
  const { email, code } = req.body;
  if (!email || !code) return res.status(400).json({ error: '请输入邮箱和验证码' });

  const verification = await queryOne(
    "SELECT * FROM email_verifications WHERE email = ? AND code = ? AND type = 'login' AND expires_at > NOW() AND used = 0 ORDER BY id DESC LIMIT 1",
    [email, code]
  );
  if (!verification) return res.status(400).json({ error: '验证码错误或已过期' });

  await run('UPDATE email_verifications SET used = 1 WHERE id = ?', [verification.id]);
  const user = await queryOne('SELECT * FROM users WHERE email = ?', [email]);
  const token = jwt.sign({ userId: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: config.jwtExpiresIn });

  res.json({
    message: '登录成功',
    token,
    user: { id: user.id, username: user.username, nickname: user.nickname, email: user.email, avatar_url: user.avatar_url, bio: user.bio, theme_name: user.theme_name, accent_color: user.accent_color, is_public: user.is_public, role: user.role }
  });
});

// 密码登录
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: '请输入邮箱和密码' });

  const user = await queryOne('SELECT * FROM users WHERE email = ?', [email]);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(400).json({ error: '邮箱或密码错误' });

  const token = jwt.sign({ userId: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: config.jwtExpiresIn });
  res.json({
    message: '登录成功',
    token,
    user: { id: user.id, username: user.username, nickname: user.nickname, email: user.email, avatar_url: user.avatar_url, bio: user.bio, theme_name: user.theme_name, accent_color: user.accent_color, is_public: user.is_public, role: user.role }
  });
});

// 获取当前用户
router.get('/me', authMiddleware, async (req, res) => {
  const user = await queryOne(
    'SELECT id, username, nickname, email, role, avatar_url, bio, theme_name, accent_color, custom_bg_url, is_public, created_at FROM users WHERE id = ?',
    [req.userId]
  );
  if (!user) return res.status(404).json({ error: '用户不存在' });

  const socialLinks = await queryAll('SELECT * FROM social_links WHERE user_id = ? ORDER BY sort_order ASC', [user.id]);
  const music = await queryOne('SELECT * FROM music_settings WHERE user_id = ?', [user.id]);
  const likeCount = (await queryOne('SELECT COUNT(*) as count FROM likes WHERE user_id = ?', [user.id]))?.count || 0;
  const visitCount = (await queryOne('SELECT COUNT(*) as count FROM visit_stats WHERE user_id = ?', [user.id]))?.count || 0;

  res.json({
    user,
    socialLinks,
    music: music || { type: 'netease', music_url: '', music_id: '', title: '', artist: '', autoplay: 0 },
    likeCount,
    visitCount
  });
});

// 初始化邮件器
emailService.init();

module.exports = { router, authMiddleware, adminMiddleware };