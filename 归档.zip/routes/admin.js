const express = require('express');
const { queryAll, queryOne, run } = require('../database');
const { adminMiddleware } = require('../middleware/auth');

const router = express.Router();

// 所有路由都需要管理员权限
router.use(adminMiddleware);

// ========== 仪表盘概览 ==========
router.get('/stats', async (req, res) => {
  try {
    const totalUsers = (await queryOne('SELECT COUNT(*) as count FROM users'))?.count || 0;
    const publicUsers = (await queryOne('SELECT COUNT(*) as count FROM users WHERE is_public = 1'))?.count || 0;
    const totalLikes = (await queryOne('SELECT COUNT(*) as count FROM likes'))?.count || 0;
    const totalVisits = (await queryOne('SELECT COUNT(*) as count FROM visit_stats'))?.count || 0;
    const adminCount = (await queryOne("SELECT COUNT(*) as count FROM users WHERE role = 'admin'"))?.count || 0;
    const todayUsers = (await queryOne("SELECT COUNT(*) as count FROM users WHERE DATE(created_at) = CURDATE()"))?.count || 0;

    res.json({
      totalUsers, publicUsers, totalLikes, totalVisits,
      adminCount, todayUsers
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ========== 用户管理 ==========

// 获取用户列表（分页+搜索）
router.get('/users', async (req, res) => {
  const { page = 1, limit = 20, search = '', sort = 'newest' } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  let orderBy = 'id DESC';
  if (sort === 'oldest') orderBy = 'id ASC';
  if (sort === 'username') orderBy = 'username ASC';

  let whereClause = '';
  const params = [];
  if (search) {
    whereClause = 'WHERE username LIKE ? OR nickname LIKE ? OR email LIKE ?';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }

  const users = await queryAll(
    `SELECT u.id, u.username, u.nickname, u.email, u.role, u.is_public, u.created_at,
      COALESCE(l.like_count, 0) as like_count,
      COALESCE(v.visit_count, 0) as visit_count
     FROM users u
     LEFT JOIN (SELECT user_id, COUNT(*) as like_count FROM likes GROUP BY user_id) l ON u.id = l.user_id
     LEFT JOIN (SELECT user_id, COUNT(*) as visit_count FROM visit_stats GROUP BY user_id) v ON u.id = v.user_id
     ${whereClause}
     ORDER BY ${orderBy}
     LIMIT ? OFFSET ?`,
    [...params, parseInt(limit), offset]
  );

  const total = (await queryOne(`SELECT COUNT(*) as count FROM users ${whereClause}`, params))?.count || 0;

  res.json({
    users,
    pagination: { page: parseInt(page), limit: parseInt(limit), total, totalPages: Math.ceil(total / parseInt(limit)) }
  });
});

// 获取单个用户详情
router.get('/users/:id', async (req, res) => {
  const user = await queryOne(
    `SELECT u.*, COALESCE(l.like_count,0) as like_count, COALESCE(v.visit_count,0) as visit_count
     FROM users u
     LEFT JOIN (SELECT user_id, COUNT(*) as like_count FROM likes GROUP BY user_id) l ON u.id = l.user_id
     LEFT JOIN (SELECT user_id, COUNT(*) as visit_count FROM visit_stats GROUP BY user_id) v ON u.id = v.user_id
     WHERE u.id = ?`,
    [req.params.id]
  );
  if (!user) return res.status(404).json({ error: '用户不存在' });

  const socialLinks = await queryAll('SELECT * FROM social_links WHERE user_id = ?', [user.id]);
  const music = await queryOne('SELECT * FROM music_settings WHERE user_id = ?', [user.id]);

  res.json({ user, socialLinks, music });
});

// 切换用户公开状态
router.put('/users/:id/toggle-public', async (req, res) => {
  const user = await queryOne('SELECT id, is_public FROM users WHERE id = ?', [req.params.id]);
  if (!user) return res.status(404).json({ error: '用户不存在' });

  const newState = user.is_public ? 0 : 1;
  await run('UPDATE users SET is_public = ? WHERE id = ?', [newState, req.params.id]);
  res.json({ message: newState ? '已公开' : '已隐藏', is_public: newState });
});

// 设置用户角色（升降管理员）
router.put('/users/:id/role', async (req, res) => {
  const { role } = req.body;
  if (!['user', 'admin'].includes(role)) return res.status(400).json({ error: '无效角色' });

  const user = await queryOne('SELECT id, username FROM users WHERE id = ?', [req.params.id]);
  if (!user) return res.status(404).json({ error: '用户不存在' });

  // 防止自己降级
  if (parseInt(req.params.id) === req.userId && role !== 'admin') {
    return res.status(400).json({ error: '不能将自己降级为普通用户' });
  }

  await run('UPDATE users SET role = ? WHERE id = ?', [role, req.params.id]);
  res.json({ message: `已设为${role === 'admin' ? '管理员' : '普通用户'}` });
});

// 删除用户
router.delete('/users/:id', async (req, res) => {
  if (parseInt(req.params.id) === req.userId) {
    return res.status(400).json({ error: '不能删除自己' });
  }

  const user = await queryOne('SELECT id, username FROM users WHERE id = ?', [req.params.id]);
  if (!user) return res.status(404).json({ error: '用户不存在' });

  // 防止删除最后一个管理员
  if (user.role === 'admin') {
    const adminCount = (await queryOne("SELECT COUNT(*) as count FROM users WHERE role = 'admin'"))?.count || 0;
    if (adminCount <= 1) {
      return res.status(400).json({ error: '不能删除最后一个管理员' });
    }
  }

  await run('DELETE FROM users WHERE id = ?', [req.params.id]);
  res.json({ message: `用户 ${user.username} 已删除` });
});

// 重置用户密码
router.post('/users/:id/reset-password', async (req, res) => {
  const bcrypt = require('bcryptjs');
  const user = await queryOne('SELECT id, username FROM users WHERE id = ?', [req.params.id]);
  if (!user) return res.status(404).json({ error: '用户不存在' });

  const newPassword = Math.random().toString(36).slice(-8);
  const passwordHash = bcrypt.hashSync(newPassword, 10);
  await run('UPDATE users SET password_hash = ? WHERE id = ?', [passwordHash, req.params.id]);

  res.json({ message: '密码已重置', newPassword, note: '请将此密码告知用户，用户登录后应尽快修改' });
});

module.exports = router;