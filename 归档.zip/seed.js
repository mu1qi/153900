/**
 * 灰·韵 HUI·YUN — 管理员账号种子脚本
 * 每次启动时检查，确保管理员账号存在
 */
const bcrypt = require('bcryptjs');
const config = require('./config');
const { queryOne, run } = require('./database');

// 管理员账号配置
const ADMIN_CONFIG = config.admin;

async function seedAdmin() {
  try {
    const existing = await queryOne('SELECT id, role FROM users WHERE username = ?', [ADMIN_CONFIG.username]);

    if (existing) {
      // 确保现有管理员角色正确
      if (existing.role !== 'admin') {
        await run('UPDATE users SET role = ? WHERE id = ?', ['admin', existing.id]);
        console.log('[种子] 管理员角色已修正');
      }
      console.log('[种子] 管理员账号已存在');
      return;
    }

    // 创建管理员账号
    const passwordHash = bcrypt.hashSync(ADMIN_CONFIG.password, 10);
    await run(
      'INSERT INTO users (username, nickname, email, password_hash, role, is_public) VALUES (?, ?, ?, ?, ?, ?)',
      [ADMIN_CONFIG.username, ADMIN_CONFIG.nickname, ADMIN_CONFIG.email, passwordHash, 'admin', 0]
    );

    console.log('========================================');
    console.log('  管理员账号已创建');
    console.log('  用户名: admin');
    console.log('  邮箱:   admin@153900.xyz');
    console.log('  密码:   admin123456');
    console.log('  请立即登录并修改密码！');
    console.log('========================================');
  } catch (err) {
    console.error('========================================');
    console.error('  ❌ 管理员账号初始化失败！');
    console.error('  错误: ' + err.message);
    console.error('  这通常是因为数据库未连接或表不存在。');
    console.error('  解决方法：');
    console.error('    1. 检查 .env 中数据库配置是否正确');
    console.error('    2. 确认 MySQL 已启动且数据库已创建');
    console.error('    3. 服务器启动后，再手动运行:');
    console.error('       node scripts/create-admin.js');
    console.error('========================================');
  }
}

module.exports = { seedAdmin, ADMIN_CONFIG };