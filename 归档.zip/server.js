require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');
const rateLimit = require('express-rate-limit');
const config = require('./config');
const { initDatabase, cleanExpiredVerifications, closePool } = require('./database');
const { seedAdmin } = require('./seed');
const { router: authRoutes } = require('./routes/auth');
const userRoutes = require('./routes/user');
const discoverRoutes = require('./routes/discover');
const uploadRoutes = require('./routes/upload');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = config.port;

// ========== 生产环境安全中间件 ==========
// 信任反向代理（Nginx / 虚拟主机）
app.set('trust proxy', 1);

// 安全响应头
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  if (config.isProduction) {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  next();
});

// 基础中间件
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// 静态文件（生产环境建议由 Nginx 直接 serve）
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: config.isProduction ? '1d' : 0
}));
app.use('/uploads', express.static(path.join(__dirname, 'uploads'), {
  maxAge: config.isProduction ? '7d' : 0
}));

// 速率限制
app.use('/api', rateLimit({
  windowMs: config.rateLimit.api.windowMs,
  max: config.rateLimit.api.max,
  message: { error: '请求过于频繁' }
}));
app.use('/api/auth', rateLimit({
  windowMs: config.rateLimit.auth.windowMs,
  max: config.rateLimit.auth.max,
  message: { error: '操作过于频繁' }
}));

// ========== 健康检查 ==========
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    uptime: Math.floor(process.uptime()),
    time: new Date().toISOString(),
    env: config.isProduction ? 'production' : 'development'
  });
});

// ========== 静态文件诊断 ==========
app.get('/debug-static', (req, res) => {
  const fs = require('fs');
  const checks = {};
  const files = [
    'public/css/style.css',
    'public/js/common.js',
    'public/assets/default-avatar.svg',
    'public/index.html'
  ];
  files.forEach(f => {
    const fullPath = path.join(__dirname, f);
    checks[f] = fs.existsSync(fullPath) ? 'OK' : 'MISSING';
  });
  res.json({
    message: '如果 CSS/JS 文件状态为 OK 但页面无样式，说明虚拟主机的 Apache/Nginx 在拦截静态文件请求。请将 .htaccess 上传到项目根目录。',
    files: checks,
    cwd: __dirname,
    publicPath: path.join(__dirname, 'public')
  });
});

// ========== API 路由 ==========
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/discover', discoverRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/admin', adminRoutes);

// ========== 前端路由 ==========
// 防止用户误访问 /public/ 路径
app.get('/public', (req, res) => res.redirect('/'));
app.get('/public/*', (req, res) => res.redirect('/'));

app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/terms', (req, res) => res.sendFile(path.join(__dirname, 'public', 'terms.html')));
app.get('/privacy', (req, res) => res.sendFile(path.join(__dirname, 'public', 'privacy.html')));
app.get('/about', (req, res) => res.sendFile(path.join(__dirname, 'public', 'about.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('/qrcode/:username', (req, res) => res.sendFile(path.join(__dirname, 'public', 'qrcode.html')));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// 用户主页 catch-all
app.get('/:username', (req, res) => {
  const reserved = ['login', 'dashboard', 'terms', 'privacy', 'about', 'qrcode', 'api', 'uploads', 'favicon.ico', 'css', 'js', 'assets', 'health'];
  if (reserved.includes(req.params.username) || req.params.username.includes('.')) {
    return res.status(404).send('Not Found');
  }
  res.sendFile(path.join(__dirname, 'public', 'profile.html'));
});

// ========== 404 ==========
app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: '接口不存在' });
  }
  res.status(404).sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ========== 全局错误处理 ==========
app.use((err, req, res, next) => {
  console.error(`[错误] ${err.message}`);
  if (config.isProduction) {
    // 生产环境不暴露错误详情
    return res.status(500).json({ error: '服务器内部错误' });
  }
  res.status(500).json({ error: err.message, stack: err.stack });
});

// ========== 优雅退出 ==========
async function gracefulShutdown(signal) {
  console.log(`\n[服务] 收到 ${signal} 信号，正在关闭...`);
  await closePool();
  process.exit(0);
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

// 未捕获异常处理
process.on('uncaughtException', (err) => {
  console.error('[致命错误]', err);
  closePool().then(() => process.exit(1));
});
process.on('unhandledRejection', (reason) => {
  console.error('[未处理拒绝]', reason);
});

// ========== 启动 ==========
async function start() {
  await initDatabase();
  console.log('[数据库] 连接成功');

  await seedAdmin();

  await cleanExpiredVerifications();
  setInterval(cleanExpiredVerifications, 60 * 60 * 1000);

  app.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════╗
║    灰·韵 HUI·YUN  v1.0.0        ║
║    个人聚合页平台                  ║
║    http://localhost:${PORT}           ║
║    环境: ${config.isProduction ? '生产' : '开发'}                     ║
╚════════════════════════════════════╝
    `);
  });
}

start().catch(err => {
  console.error('启动失败:', err);
  process.exit(1);
});