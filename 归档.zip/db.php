<?php
/**
 * 灰·韵 HUI·YUN — 数据库层
 * 替代原来的 database.js
 */

require_once __DIR__ . '/config.php';

$__pdo = null;

function getDB() {
    global $__pdo;
    if ($__pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $__pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            jsonError(500, '数据库连接失败: ' . $e->getMessage());
        }
    }
    return $__pdo;
}

function queryAll($sql, $params = []) {
    $stmt = getDB()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function queryOne($sql, $params = []) {
    $stmt = getDB()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetch() ?: null;
}

function dbRun($sql, $params = []) {
    $stmt = getDB()->prepare($sql);
    $stmt->execute($params);
    return [
        'lastInsertId' => (int) getDB()->lastInsertId(),
        'rowCount' => $stmt->rowCount()
    ];
}

/**
 * 初始化数据库表（首次运行时调用）
 */
function initDatabase() {
    $db = getDB();
    
    $tables = [
        "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(20) NOT NULL UNIQUE,
            nickname VARCHAR(30) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(10) DEFAULT 'user',
            avatar_url VARCHAR(255) DEFAULT '',
            bio TEXT,
            is_public TINYINT(1) DEFAULT 1,
            custom_bg_url VARCHAR(255) DEFAULT '',
            theme_name VARCHAR(20) DEFAULT 'sakura',
            accent_color VARCHAR(10) DEFAULT '#ff6b9d',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_username (username),
            INDEX idx_email (email),
            INDEX idx_role (role)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        "CREATE TABLE IF NOT EXISTS email_verifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(100) NOT NULL,
            code VARCHAR(10) NOT NULL,
            type VARCHAR(20) NOT NULL DEFAULT 'register',
            expires_at DATETIME NOT NULL,
            used TINYINT(1) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        "CREATE TABLE IF NOT EXISTS social_links (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            platform VARCHAR(30) NOT NULL,
            platform_label VARCHAR(30) NOT NULL,
            url VARCHAR(500) NOT NULL,
            icon_svg TEXT,
            sort_order INT DEFAULT 0,
            link_type VARCHAR(10) DEFAULT 'link',
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        "CREATE TABLE IF NOT EXISTS music_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL UNIQUE,
            type VARCHAR(20) DEFAULT 'netease',
            music_url VARCHAR(500) DEFAULT '',
            music_id TEXT,
            title VARCHAR(100) DEFAULT '',
            artist VARCHAR(100) DEFAULT '',
            autoplay TINYINT(1) DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        "CREATE TABLE IF NOT EXISTS likes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            liked_by_ip VARCHAR(45) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY uk_user_ip (user_id, liked_by_ip),
            INDEX idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        "CREATE TABLE IF NOT EXISTS visit_stats (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            visitor_ip VARCHAR(45) NOT NULL,
            visited_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user (user_id),
            INDEX idx_visited (user_id, visitor_ip, visited_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    ];

    foreach ($tables as $sql) {
        $db->exec($sql);
    }

    // 迁移：为旧数据库添加 role 列
    try { $db->exec("ALTER TABLE users ADD COLUMN role VARCHAR(10) DEFAULT 'user'"); } catch (Exception $e) {}
    try { $db->exec("ALTER TABLE users ADD INDEX idx_role (role)"); } catch (Exception $e) {}
    try { $db->exec("ALTER TABLE social_links ADD COLUMN link_type VARCHAR(10) DEFAULT 'link'"); } catch (Exception $e) {}
}

function cleanExpiredVerifications() {
    try {
        dbRun("DELETE FROM email_verifications WHERE expires_at < NOW()");
    } catch (Exception $e) {}
}